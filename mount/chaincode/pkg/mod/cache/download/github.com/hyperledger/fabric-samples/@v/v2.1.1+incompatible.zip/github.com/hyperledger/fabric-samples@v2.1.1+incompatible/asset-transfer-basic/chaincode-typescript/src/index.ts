/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { AssetTransfer } from './assetTransfer';
export { AssetTransfer } from './assetTransfer';

export const contracts: any[] = [AssetTransfer];
